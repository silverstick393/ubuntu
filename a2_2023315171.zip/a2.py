# Wormy (a Nibbles clone)
# By Al Sweigart al@inventwithpython.com
# http://inventwithpython.com/pygame
# Released under a "Simplified BSD" license

import random, pygame, sys
from pygame.locals import *

FPS = 13
WINDOWWIDTH = 640
WINDOWHEIGHT = 480
CELLSIZE = 20
assert WINDOWWIDTH % CELLSIZE == 0, "Window width must be a multiple of cell size."
assert WINDOWHEIGHT % CELLSIZE == 0, "Window height must be a multiple of cell size."
CELLWIDTH = int(WINDOWWIDTH / CELLSIZE)
CELLHEIGHT = int(WINDOWHEIGHT / CELLSIZE)

#             R    G    B
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
DARKRED = (139, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
DARKBLUE = (0, 0, 139)
ORANGE = (255, 127, 0)
DARKORANGE = (139, 64, 0)
SILVER = (192, 192, 192)
DARKGREEN = (0, 155, 0)
DARKGRAY = (40, 40, 40)
YELLOW = (255, 255, 0)
DARKYELLOW = (139, 128, 0)
BGCOLOR = BLACK
INDIGO = (75, 0, 130)
DARKINDIGO = (44,42,99)
PURPLE = (160, 32, 240)
DARKPURPLE = (54, 1, 63)
UP = 'up'
DOWN = 'down'
LEFT = 'left'
RIGHT = 'right'

HEAD = 0  # syntactic sugar: index of the worm's head


def main():
    global FPSCLOCK, DISPLAYSURF, BASICFONT

    pygame.init()
    FPSCLOCK = pygame.time.Clock()
    DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
    BASICFONT = pygame.font.Font('freesansbold.ttf', 18)
    pygame.display.set_caption('Wormy')

    showStartScreen()
    while True:
        runGame()
        showGameOverScreen()


def runGame():
    # Inital settings
    global FPS
    FPS = 13

    global BGCOLOR
    BGCOLOR = BLACK

    score = 0

    # Set a random start point.
    startx = random.randint(5, CELLWIDTH - 6)
    starty = random.randint(5, CELLHEIGHT - 6)
    wormCoords = [{'x': startx, 'y': starty},
                  {'x': startx - 1, 'y': starty},
                  {'x': startx - 2, 'y': starty}]
    direction = RIGHT

    # Set a wall coordinate.
    startx_wall = random.randint(1, CELLWIDTH - 2)
    starty_wall = random.randint(1, CELLHEIGHT - 2)
    wallCoords = [{'x': startx_wall, 'y': starty_wall},
                  {'x': startx_wall - 1, 'y': starty_wall},
                  {'x': startx_wall, 'y': starty_wall - 1},
                  {'x': startx_wall - 1, 'y': starty_wall - 1}]

    # Start the target in a random place.
    color = RED
    target = getRandomLocation()

    # Check if target is on Wall
    for coord in wallCoords:
        if target == coord:
            target = getRandomLocation()

    while True:  # main game loop
        for event in pygame.event.get():  # event handling loop
            if event.type == QUIT:
                terminate()
            elif event.type == KEYDOWN:
                if (event.key == K_LEFT or event.key == K_a) and direction != RIGHT:
                    direction = LEFT
                elif (event.key == K_RIGHT or event.key == K_d) and direction != LEFT:
                    direction = RIGHT
                elif (event.key == K_UP or event.key == K_w) and direction != DOWN:
                    direction = UP
                elif (event.key == K_DOWN or event.key == K_s) and direction != UP:
                    direction = DOWN
                elif event.key == K_ESCAPE:
                    terminate()

        # check if the worm has hit itself or the edge
        if wormCoords[HEAD]['x'] == -1 or wormCoords[HEAD]['x'] == CELLWIDTH or wormCoords[HEAD]['y'] == -1 or wormCoords[HEAD]['y'] == CELLHEIGHT:
            return  # game over
        for wormBody in wormCoords[1:]:
            if wormBody['x'] == wormCoords[HEAD]['x'] and wormBody['y'] == wormCoords[HEAD]['y']:
                return  # game over
        for coord in wallCoords:
            if wormCoords[HEAD] == coord:
                return # game over

        # random creates one digit interger from 0 to 10, you may use this number during implementation
        random_number = random.randint(0, 10)


        # set Wall Position randomly by 1/100 probabilty
        if(random.randint(0, 100) == 0):
            wallCoords = setRandomWallPos()

        #*************************************Edit here!*************************************#
        colorSelector = [RED, BLUE, ORANGE, SILVER]
        select_number = random_number % 4
        Previostarget = target
        # check if worm has eaten an red target
        if wormCoords[HEAD]['x'] == target['x'] and wormCoords[HEAD]['y'] == target['y'] and color == RED:
            while(True):
                target = getRandomLocation()
                for coord in wallCoords:
                    if target == coord:
                        target = getRandomLocation()
                if target != Previostarget:
                    break            
            score += 1
            color = colorSelector[select_number]
        # check if worm has eaten an blue target
        elif wormCoords[HEAD]['x'] == target['x'] and wormCoords[HEAD]['y'] == target['y'] and color == BLUE:
            del wormCoords[-1]
            del wormCoords[-1]
            while(True):
                target = getRandomLocation()
                for coord in wallCoords:
                    if target == coord:
                        target = getRandomLocation()
                if target != Previostarget:
                    break
            score += 1
            color = colorSelector[select_number]
        # check if worm has eaten an orange target
        elif wormCoords[HEAD]['x'] == target['x'] and wormCoords[HEAD]['y'] == target['y'] and color == ORANGE:
            if 5 < FPS and FPS < 22:
                FPS += 3
            del wormCoords[-1]
            while(True):
                target = getRandomLocation()
                for coord in wallCoords:
                    if target == coord:
                        target = getRandomLocation()
                if target != Previostarget:
                    break
            score += 1
            color = colorSelector[select_number]
            

        # check if worm has eaten an silver target
        elif wormCoords[HEAD]['x'] == target['x'] and wormCoords[HEAD]['y'] == target['y'] and color == SILVER:
            wormCoords[HEAD], wormCoords[-1] = wormCoords[-1], wormCoords[HEAD]
            if(direction == UP): direction = DOWN
            elif(direction == DOWN): direction = UP
            elif(direction == LEFT): direction = RIGHT
            elif(direction == RIGHT): direction = LEFT
            del wormCoords[-1]
            while(True):
                target = getRandomLocation()
                for coord in wallCoords:
                    if target == coord:
                        target = getRandomLocation()
                if target != Previostarget:
                    break
            score += 1
            color = colorSelector[select_number]

        # worm has eaten nothing
        else:
            del wormCoords[-1]  # remove worm's tail segment

        #*************************************Edit here!*************************************#
            
        # move the worm by adding a segment in the direction it is moving
        if direction == UP:
            newHead = {'x': wormCoords[HEAD]['x'], 'y': wormCoords[HEAD]['y'] - 1}
        elif direction == DOWN:
            newHead = {'x': wormCoords[HEAD]['x'], 'y': wormCoords[HEAD]['y'] + 1}
        elif direction == LEFT:
            newHead = {'x': wormCoords[HEAD]['x'] - 1, 'y': wormCoords[HEAD]['y']}
        elif direction == RIGHT:
            newHead = {'x': wormCoords[HEAD]['x'] + 1, 'y': wormCoords[HEAD]['y']}

        wormCoords.insert(0, newHead)
        DISPLAYSURF.fill(BGCOLOR)
        drawGrid()
        drawWorm(wormCoords)
        drawWall(wallCoords)
        drawTarget(target, color)
        drawScore(score, len(wormCoords), FPS)
        pygame.display.update()
        FPSCLOCK.tick(FPS)


def drawPressKeyMsg():
    pressKeySurf = BASICFONT.render('Press a key to play.', True, DARKGRAY)
    pressKeyRect = pressKeySurf.get_rect()
    pressKeyRect.topleft = (WINDOWWIDTH - 200, WINDOWHEIGHT - 30)
    DISPLAYSURF.blit(pressKeySurf, pressKeyRect)


def checkForKeyPress():
    if len(pygame.event.get(QUIT)) > 0:
        terminate()

    keyUpEvents = pygame.event.get(KEYUP)
    if len(keyUpEvents) == 0:
        return None
    if keyUpEvents[0].key == K_ESCAPE:
        terminate()
    return keyUpEvents[0].key


def showStartScreen():
    titleFont = pygame.font.Font('freesansbold.ttf', 100)
    titleSurf1 = titleFont.render('Wormy!', True, WHITE, DARKGREEN)
    titleSurf2 = titleFont.render('Wormy!', True, GREEN)

    degrees1 = 0
    degrees2 = 0
    while True:
        DISPLAYSURF.fill(BGCOLOR)
        rotatedSurf1 = pygame.transform.rotate(titleSurf1, degrees1)
        rotatedRect1 = rotatedSurf1.get_rect()
        rotatedRect1.center = (WINDOWWIDTH / 2, WINDOWHEIGHT / 2)
        DISPLAYSURF.blit(rotatedSurf1, rotatedRect1)

        rotatedSurf2 = pygame.transform.rotate(titleSurf2, degrees2)
        rotatedRect2 = rotatedSurf2.get_rect()
        rotatedRect2.center = (WINDOWWIDTH / 2, WINDOWHEIGHT / 2)
        DISPLAYSURF.blit(rotatedSurf2, rotatedRect2)

        drawPressKeyMsg()

        if checkForKeyPress():
            pygame.event.get()  # clear event queue
            return
        pygame.display.update()
        FPSCLOCK.tick(FPS)
        degrees1 += 3  # rotate by 3 degrees each frame
        degrees2 += 7  # rotate by 7 degrees each frame


def terminate():
    pygame.quit()
    sys.exit()


def getRandomLocation():
    return {'x': random.randint(1, CELLWIDTH - 2), 'y': random.randint(1, CELLHEIGHT - 2)}


def showGameOverScreen():
    gameOverFont = pygame.font.Font('freesansbold.ttf', 150)
    gameSurf = gameOverFont.render('Game', True, WHITE)
    overSurf = gameOverFont.render('Over', True, WHITE)
    gameRect = gameSurf.get_rect()
    overRect = overSurf.get_rect()
    gameRect.midtop = (WINDOWWIDTH / 2, 10)
    overRect.midtop = (WINDOWWIDTH / 2, gameRect.height + 10 + 25)

    DISPLAYSURF.blit(gameSurf, gameRect)
    DISPLAYSURF.blit(overSurf, overRect)
    drawPressKeyMsg()
    pygame.display.update()
    pygame.time.wait(500)
    checkForKeyPress()  # clear out any key presses in the event queue

    while True:
        if checkForKeyPress():
            pygame.event.get()  # clear event queue
            return


def drawScore(score, length, fps):
    scoreSurf = BASICFONT.render('Score: %d' % (score), True, WHITE)
    scoreRect = scoreSurf.get_rect()
    scoreRect.topleft = (WINDOWWIDTH - 120, 10)
    DISPLAYSURF.blit(scoreSurf, scoreRect)
    scoreSurf = BASICFONT.render('Length: %d' % (length), True, WHITE)
    scoreRect = scoreSurf.get_rect()
    scoreRect.topleft = (WINDOWWIDTH - 120, 40)
    DISPLAYSURF.blit(scoreSurf, scoreRect)
    scoreSurf = BASICFONT.render('FPS: %d' % (fps), True, WHITE)
    scoreRect = scoreSurf.get_rect()
    scoreRect.topleft = (WINDOWWIDTH - 120, 70)
    DISPLAYSURF.blit(scoreSurf, scoreRect)


def drawWorm(wormCoords):
    Outcolor = [DARKRED, DARKORANGE, DARKYELLOW, DARKGREEN, DARKBLUE, DARKINDIGO, DARKPURPLE]
    Incolor = [RED, ORANGE, YELLOW, GREEN, BLUE, INDIGO, PURPLE]
    coloridx = 0

    for coord in wormCoords:
        x = coord['x'] * CELLSIZE
        y = coord['y'] * CELLSIZE
        wormSegmentRect = pygame.Rect(x, y, CELLSIZE, CELLSIZE)
        pygame.draw.rect(DISPLAYSURF, Outcolor[coloridx % 7], wormSegmentRect)
        wormInnerSegmentRect = pygame.Rect(x + 4, y + 4, CELLSIZE - 8, CELLSIZE - 8)
        pygame.draw.rect(DISPLAYSURF, Incolor[coloridx % 7], wormInnerSegmentRect)
        coloridx += 1

def drawTarget(coord, color):
    x = coord['x'] * CELLSIZE
    y = coord['y'] * CELLSIZE
    targetRect = pygame.Rect(x, y, CELLSIZE, CELLSIZE)
    pygame.draw.rect(DISPLAYSURF, color, targetRect)

def setRandomWallPos():
    target = getRandomLocation()
    x = target['x']
    y = target['y']
    wallCoords = [{'x': x, 'y': y},
                  {'x': x - 1, 'y': y},
                  {'x': x, 'y': y - 1},
                  {'x': x - 1, 'y': y - 1}]
    return wallCoords


def drawWall(wallCoords):
    for coord in wallCoords:
        x = coord['x'] * CELLSIZE
        y = coord['y'] * CELLSIZE
        targetRect = pygame.Rect(x, y, CELLSIZE, CELLSIZE)
        pygame.draw.rect(DISPLAYSURF, WHITE, targetRect)


def drawGrid():
    for x in range(0, WINDOWWIDTH, CELLSIZE):  # draw vertical lines
        pygame.draw.line(DISPLAYSURF, DARKGRAY, (x, 0), (x, WINDOWHEIGHT))
    for y in range(0, WINDOWHEIGHT, CELLSIZE):  # draw horizontal lines
        pygame.draw.line(DISPLAYSURF, DARKGRAY, (0, y), (WINDOWWIDTH, y))


if __name__ == '__main__':
    main()
