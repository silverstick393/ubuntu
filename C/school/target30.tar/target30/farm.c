/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_185(unsigned *p)
{
    *p = 2425378841U;
}

unsigned addval_407(unsigned x)
{
    return x + 2425378858U;
}

unsigned addval_494(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_406(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_116()
{
    return 2462550344U;
}

void setval_113(unsigned *p)
{
    *p = 3251079496U;
}

unsigned getval_313()
{
    return 3281162328U;
}

unsigned getval_115()
{
    return 3080307528U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_232(unsigned *p)
{
    *p = 3285109085U;
}

unsigned addval_452(unsigned x)
{
    return x + 247583113U;
}

void setval_226(unsigned *p)
{
    *p = 2425409931U;
}

unsigned getval_346()
{
    return 3687109001U;
}

unsigned addval_320(unsigned x)
{
    return x + 3223372425U;
}

unsigned getval_311()
{
    return 2425475465U;
}

void setval_430(unsigned *p)
{
    *p = 3281109641U;
}

void setval_450(unsigned *p)
{
    *p = 3372794497U;
}

unsigned addval_236(unsigned x)
{
    return x + 3281047817U;
}

void setval_144(unsigned *p)
{
    *p = 3683962505U;
}

unsigned getval_225()
{
    return 3286272328U;
}

void setval_111(unsigned *p)
{
    *p = 3534016137U;
}

unsigned addval_153(unsigned x)
{
    return x + 2428684666U;
}

unsigned getval_257()
{
    return 3352201656U;
}

unsigned addval_424(unsigned x)
{
    return x + 3375943337U;
}

unsigned getval_146()
{
    return 3286272330U;
}

void setval_181(unsigned *p)
{
    *p = 2425406093U;
}

unsigned getval_173()
{
    return 3224949129U;
}

void setval_178(unsigned *p)
{
    *p = 3353381192U;
}

void setval_152(unsigned *p)
{
    *p = 3286280520U;
}

unsigned getval_172()
{
    return 3767355497U;
}

void setval_222(unsigned *p)
{
    *p = 3380920969U;
}

void setval_440(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_203(unsigned x)
{
    return x + 3676360329U;
}

unsigned addval_199(unsigned x)
{
    return x + 3526938251U;
}

void setval_299(unsigned *p)
{
    *p = 3372798337U;
}

unsigned getval_344()
{
    return 3531919753U;
}

unsigned addval_338(unsigned x)
{
    return x + 3281044109U;
}

unsigned getval_444()
{
    return 3677933193U;
}

unsigned addval_261(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_204()
{
    return 2497743176U;
}

unsigned getval_386()
{
    return 2425668233U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
