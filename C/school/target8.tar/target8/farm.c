/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_197(unsigned *p)
{
    *p = 365006936U;
}

void setval_210(unsigned *p)
{
    *p = 3347663060U;
}

unsigned getval_416()
{
    return 2425378941U;
}

void setval_108(unsigned *p)
{
    *p = 3347662921U;
}

unsigned getval_266()
{
    return 3284633930U;
}

unsigned getval_462()
{
    return 2428995904U;
}

void setval_239(unsigned *p)
{
    *p = 3281017045U;
}

void setval_414(unsigned *p)
{
    *p = 2143516679U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_159()
{
    return 3225995913U;
}

unsigned addval_436(unsigned x)
{
    return x + 3687104905U;
}

unsigned addval_398(unsigned x)
{
    return x + 3232022921U;
}

void setval_203(unsigned *p)
{
    *p = 2445379995U;
}

unsigned addval_329(unsigned x)
{
    return x + 3674262153U;
}

unsigned addval_485(unsigned x)
{
    return x + 3677929867U;
}

unsigned getval_218()
{
    return 3286272328U;
}

unsigned getval_201()
{
    return 3286270280U;
}

unsigned getval_331()
{
    return 398576265U;
}

unsigned addval_437(unsigned x)
{
    return x + 2429192639U;
}

void setval_228(unsigned *p)
{
    *p = 3380926089U;
}

unsigned addval_110(unsigned x)
{
    return x + 3374369409U;
}

unsigned addval_461(unsigned x)
{
    return x + 3281043853U;
}

unsigned addval_115(unsigned x)
{
    return x + 2430634824U;
}

unsigned getval_134()
{
    return 3252717896U;
}

unsigned getval_276()
{
    return 46651017U;
}

unsigned addval_136(unsigned x)
{
    return x + 3374367113U;
}

unsigned getval_260()
{
    return 2464188744U;
}

unsigned getval_441()
{
    return 1455675017U;
}

void setval_470(unsigned *p)
{
    *p = 3223372185U;
}

void setval_209(unsigned *p)
{
    *p = 3264272009U;
}

unsigned addval_330(unsigned x)
{
    return x + 3281043849U;
}

unsigned addval_245(unsigned x)
{
    return x + 3232028297U;
}

unsigned addval_405(unsigned x)
{
    return x + 3229931161U;
}

unsigned addval_423(unsigned x)
{
    return x + 985909769U;
}

unsigned addval_433(unsigned x)
{
    return x + 3221280393U;
}

unsigned addval_171(unsigned x)
{
    return x + 3286272332U;
}

unsigned addval_469(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_446()
{
    return 2429192671U;
}

void setval_382(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_132()
{
    return 3685010057U;
}

unsigned addval_129(unsigned x)
{
    return x + 3682916041U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
